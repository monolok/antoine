# Antoine

Antoine is ...
You can install Antoine directly from GitHub using pip.

## Hire Antoine with a quick pip install

```bash
## Installing
pip install git+https://github.com/monolok/antoine.git

## Upgrading
pip install git+https://github.com/monolok/antoine.git --upgrade

## Running in terminal
$ hireantoinenow